const BACKEND_PORT = 3010;
//const BACKEND_URL = 'https://localhost';
const BACKEND_URL = 'https://seserverneu.se.hs-heilbronn.de';
export { BACKEND_URL, BACKEND_PORT }

